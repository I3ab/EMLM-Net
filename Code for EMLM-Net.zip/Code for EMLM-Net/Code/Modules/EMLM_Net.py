"""
Description: Superpixel-based EMLM-network
"""
# Futures
from __future__ import print_function

import sys
import os

import keras.layers
import numpy as np
from keras import Model

# getting the directory where this file is located
current_dir = os.path.dirname(os.path.realpath(__file__))
# getting the parent directory and adding it to the path
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from Modules.utils import *
from Modules.Losses import *
from tensorflow.keras.callbacks import Callback
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Layer, Dense
from tensorflow.keras.constraints import Constraint
import tensorflow.keras.initializers as initializers
import tensorflow.keras.backend as K
import tensorflow as tf
import scipy.linalg as splin
import scipy as sp
import numpy as np
from keras.layers import Reshape
from keras.layers.core import Flatten
from keras import regularizers
# ---------------------------------------------------------------------------------------------
# Customize keras layer for unfolding ADMM
# ---------------------------------------------------------------------------------------------
class Update_a_layer(Layer):
    def __init__(self, units, W_initializer, B_initializer, **kwargs):
        self.units = units
        self.W_initializer = initializers.get(W_initializer)
        self.B_initializer = initializers.get(B_initializer)

        super(Update_a_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        # parse shape
        v1_shape, _, _, _ = input_shape
        obs_dim = v1_shape[-1]

        # add trainable params
        self.W = self.add_weight(name='W',
                                 shape=(obs_dim, self.units),
                                 initializer=self.W_initializer,
                                 trainable=True)

        self.B = self.add_weight(name='B',
                                 shape=(self.units, self.units),
                                 initializer=self.B_initializer,
                                 trainable=True)
        self.built = True

    def call(self, x):
        assert isinstance(x, list)
        v1, d1, v2, d2 = x

        output = K.dot(v1+d1, self.W) + K.dot(v2+d2, self.B)
        # check the output_dim
        assert (K.int_shape(v2) == K.int_shape(output))
        return output

    def get_config(self):
        config = {'units': self.units,
                  'W_initializer': initializers.serialize(self.W_initializer),
                  'B_initializer': initializers.serialize(self.B_initializer) }

        base_config = super(Update_a_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        # parse shape
        _, _, v2_input_shape, _ = input_shape
        return v2_input_shape

class Update_p_layer(Layer):
    def __init__(self, units, scalar_theta, theta_initializer, **kwargs):
        self.units = units
        self.scalar_theta = scalar_theta
        self.theta_initializer = initializers.get(theta_initializer)

        super(Update_p_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        # parse input_shape
        x_shape, _, _, _ = input_shape
        obs_dim = x_shape[-1]

        assert obs_dim == self.units

        # define the shape of theta
        if self.scalar_theta:  # scalar theta
           self.theta_shape = (1,)
        else:
           self.theta_shape = (obs_dim,)

        # add trainable params
        self.theta = self.add_weight(name='theta',
                                     shape=self.theta_shape,
                                     initializer=self.theta_initializer,
                                     trainable=True)

        self.built = True  # Be sure to call this at the end

    def call(self, x):
        assert (isinstance(x, list))
        input, v1, v3, d3 = x
        tmp1 = tf.multiply(v1,input)-v1
        a1 = tf.multiply(input-v1,tmp1)+(v3+d3)*self.theta
        b1 = tf.multiply(tmp1,tmp1) + self.theta + 1e-6
        output = tf.divide(a1, b1)
        return output

    def get_config(self):
        config = {'units': self.units,
                  'scalar_theta': self.scalar_theta,
                  'theta_initializer': initializers.serialize(self.theta_initializer)}

        base_config = super(Update_p_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        # parse shape
        _, _, v3_input_shape, _ = input_shape
        return v3_input_shape

class Update_v1_layer(Layer):
    def __init__(self, units, C_initializer, scalar_eta, eta_initializer, **kwargs):
        self.units = units
        self.C_initializer = initializers.get(C_initializer)
        self.scalar_eta = scalar_eta
        self.eta_initializer = initializers.get(eta_initializer)

        super(Update_v1_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        # parse input_shape
        x_shape, a_shape, _, _ = input_shape
        obs_dim = x_shape[-1]
        code_dim = a_shape[-1]

        assert obs_dim == self.units
        # define the shape of theta
        if self.scalar_eta:  # scalar theta
           self.eta_shape = (1,)
        else:
           self.eta_shape = (obs_dim,)

        # add trainable params
        self.C = self.add_weight(name='C',
                                 shape=(code_dim, obs_dim),
                                 initializer=self.C_initializer,
                                 trainable=True)

        self.eta = self.add_weight(name='eta',
                                   shape=self.eta_shape,
                                   initializer=self.eta_initializer,
                                   trainable=True)

        self.built = True  # Be sure to call this at the end

    def call(self, x):
        assert (isinstance(x, list))
        input, a, p, d1 = x
        tmp2 = tf.ones_like(p) - p + tf.multiply(p,input)
        a2 = tf.multiply(input,tmp2) * self.eta + K.dot(a,self.C)-d1
        b2 = tf.multiply(tmp2,tmp2) * self.eta + tf.ones_like(p)
        output = tf.divide(a2, b2)
        return output

    def get_config(self):
        config = {'units': self.units,
                  'C_initializer': initializers.serialize(self.C_initializer),
                  'scalar_eta': self.scalar_eta,
                  'eta_initializer': initializers.serialize(self.eta_initializer)}

        base_config = super(Update_v1_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        # parse shape
        _, _, p_input_shape, _ = input_shape
        return p_input_shape

class Update_v2_layer(Layer):
    def __init__(self, units, scalar_rho, rho_initializer, **kwargs):
        self.units = units
        self.scalar_rho = scalar_rho
        self.rho_initializer = initializers.get(rho_initializer)

        super(Update_v2_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        a_shape, _ = input_shape
        code_dim = a_shape[-1]
        assert code_dim == self.units

        # define the shape of threshold
        if self.scalar_rho:  # scalar threshold
           self.rho_shape = (1,)
        else:
           self.rho_shape = (code_dim,)

        # Create a trainable weight variable for this layer.
        self.rho = self.add_weight(name='rho',
                                   shape=self.rho_shape,
                                   initializer=self.rho_initializer,
                                   trainable=True)

        self.built = True  # Be sure to call this at the end

    def call(self, x):
        assert isinstance(x, list)
        a, d2 = x
        return K.relu(a-d2-self.rho)

    def get_config(self):
        config = {'units': self.units,
                  'scalar_rho': self.scalar_rho,
                  'rho_initializer': initializers.serialize(self.rho_initializer)}

        base_config = super(Update_v2_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        a_input_shape, _ = input_shape
        return a_input_shape

class Update_v3_layer(Layer):
    def __init__(self, units, D_initializer, **kwargs):
        self.units = units
        self.D_initializer = initializers.get(D_initializer)

        super(Update_v3_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        # parse input_shape
        p_shape, _ = input_shape
        obs_dim = p_shape[-1]
        assert obs_dim == self.units

        # add trainable params
        self.D = self.add_weight(name='D',
                                 shape=(obs_dim, obs_dim),
                                 initializer=self.D_initializer,
                                 trainable=True)

        self.built = True  # Be sure to call this at the end

    def call(self, x):
        assert (isinstance(x, list))
        p, d3 = x

        output = tf.ones_like(p)-K.relu(tf.ones_like(p)-K.dot(p-d3,self.D))
        return output

    def get_config(self):
        config = {'units': self.units,
                  'D_initializer': initializers.serialize(self.D_initializer)}

        base_config = super(Update_v3_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        p_input_shape, _ = input_shape
        return p_input_shape

class Update_d1_layer(Layer):
    def __init__(self, units, F_initializer, scalar_sigma1, sigma1_initializer, **kwargs):
        self.units = units
        self.F_initializer = initializers.get(F_initializer)
        self.scalar_sigma1 = scalar_sigma1
        self.sigma1_initializer = initializers.get(sigma1_initializer)

        super(Update_d1_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        d1_shape, a_shape, _ = input_shape
        obs_dim = d1_shape[-1]
        code_dim = a_shape[-1]

        assert obs_dim == self.units

        # define the shape of threshold
        if self.scalar_sigma1:  # scalar threshold
            self.sigma1_shape = (1,)
        else:
            self.sigma1_shape = (obs_dim,)

        # Create a trainable weight variable for this layer.
        self.F = self.add_weight(name='F',
                                 shape=(code_dim, obs_dim),
                                 initializer=self.F_initializer,
                                 trainable=True)

        self.sigma1 = self.add_weight(name='sigma1',
                                      shape=self.sigma1_shape,
                                      initializer=self.sigma1_initializer,
                                      trainable=True)

        self.built = True  # Be sure to call this at the end

    def call(self, x):
        assert isinstance(x, list)
        d1, a, v1 = x
        return d1* self.sigma1 - (K.dot(a, self.F) - v1)

    def get_config(self):
        config = {'units': self.units,
                  'F_initializer': initializers.serialize(self.F_initializer),
                  'scalar_sigma1': self.scalar_sigma1,
                  'sigma1_initializer': initializers.serialize(self.sigma1_initializer)}

        base_config = super(Update_d1_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        d1_input_shape, _, _ = input_shape
        return d1_input_shape

class Update_d2_layer(Layer):
    def __init__(self, units, scalar_sigma2, sigma2_initializer, **kwargs):
        self.units = units
        self.scalar_sigma2 = scalar_sigma2
        self.sigma2_initializer = initializers.get(sigma2_initializer)

        super(Update_d2_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        d2_shape, _, _ = input_shape
        code_dim = d2_shape[-1]
        assert code_dim == self.units

        # define the shape of threshold
        if self.scalar_sigma2:  # scalar threshold
            self.sigma2_shape = (1,)
        else:
            self.sigma2_shape = (code_dim,)

        # Create a trainable weight variable for this layer.
        self.sigma2 = self.add_weight(name='sigma2',
                                      shape=self.sigma2_shape,
                                      initializer=self.sigma2_initializer,
                                      trainable=True)

        self.built = True  # Be sure to call this at the end

    def call(self, x):
        assert isinstance(x, list)
        d2, a, v2 = x
        return d2 - (a - v2) * self.sigma2

    def get_config(self):
        config = {'units': self.units,
                  'scalar_sigma2': self.scalar_sigma2,
                  'sigma2_initializer': initializers.serialize(self.sigma2_initializer)}

        base_config = super(Update_d2_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        d2_input_shape, _, _ = input_shape
        return d2_input_shape

class Update_d3_layer(Layer):
    def __init__(self, units, scalar_sigma3, sigma3_initializer, **kwargs):
        self.units = units
        self.scalar_sigma3 = scalar_sigma3
        self.sigma3_initializer = initializers.get(sigma3_initializer)

        super(Update_d3_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        d3_shape, _, _ = input_shape
        obs_dim = d3_shape[-1]
        assert obs_dim == self.units

        # define the shape of threshold
        if self.scalar_sigma3:  # scalar threshold
            self.sigma3_shape = (1,)
        else:
            self.sigma3_shape = (obs_dim,)

        # Create a trainable weight variable for this layer.
        self.sigma3 = self.add_weight(name='sigma3',
                                      shape=self.sigma3_shape,
                                      initializer=self.sigma3_initializer,
                                      trainable=True)

        self.built = True  # Be sure to call this at the end

    def call(self, x):
        assert isinstance(x, list)
        d3, p, v3 = x
        return d3 - (p - v3) * self.sigma3

    def get_config(self):
        config = {'units': self.units,
                  'scalar_sigma3': self.scalar_sigma3,
                  'sigma3_initializer': initializers.serialize(self.sigma3_initializer)}

        base_config = super(Update_d3_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        d3_input_shape, _, _ = input_shape
        return d3_input_shape

class Norm_layer(Layer):
    def __init__(self, **kwargs):
        super(Norm_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        self.built = True  # Be sure to call this at the end

    def call(self, x):
        x = x + 1e-6
        return x / tf.norm(x, ord=1, axis=-1, keepdims=True)

    def get_config(self):
        base_config = super(Norm_layer, self).get_config()
        return base_config

    def compute_output_shape(self, input_shape):
        return input_shape

# EMLM-based decoder
class Recon_layer(Layer):
    def __init__(self, units, **kwargs):
        self.units = units
        super(Recon_layer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)
        v1_shape, _ = input_shape
        obs_dim = v1_shape[-1]
        assert obs_dim == self.units
        self.built = True  # Be sure to call this at the end

    def call(self, x):
        assert isinstance(x, list)
        v1, v3 = x
        a3 = tf.multiply(tf.ones_like(v3)-v3, v1)
        b3 = tf.ones_like(v3) - tf.multiply(v3, v1)
        return tf.divide(a3,b3)

    def get_config(self):
        config = {'units': self.units}
        base_config = super(Recon_layer, self).get_config()

        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        v1_input_shape, _ = input_shape
        return v1_input_shape

# ---------------------------------------------------------------------------------------------
# customize endm signature constraint： constrain endm signature in range [0,1]
# ---------------------------------------------------------------------------------------------
class MinMaxVal(Constraint):
    def __init__(self, min_value, max_value):
        self.min_value = min_value
        self.max_value = max_value

    def __call__(self, w):
        temp = w
        temp = K.maximum(temp, self.min_value)
        temp = K.minimum(temp, self.max_value)
        return temp

    def get_config(self):
        return {'min_value': self.min_value,
                'max_value': self.max_value}

# ---------------------------------------------------------------------------------------------
# Unfolding ADMM network for EMLM-based unsupervised unmixing
# ---------------------------------------------------------------------------------------------
class EMLM:
    def __init__(self, input_shape, input_patch, output_shape, number_layers,
                 beta, gamma, name='EMLM',
                 Endm_initialization=None, E=None, L=None,
                 lambda_0=None, tau_0=None, mu_0=None,
                 scalar_theta=True, scalar_eta=True, scalar_rho=True,
                 scalar_sigma1=True, scalar_sigma2=True, scalar_sigma3=True):
        self.input_shape = input_shape
        self.input_patch = input_patch
        self.output_shape = output_shape
        self.beta = beta
        self.gamma = gamma
        self.number_layers = number_layers
        self.name = name
        self.Endm_initialization = Endm_initialization
        self.E = E
        self.L = L
        self.lambda_0 = lambda_0
        self.tau_0 = tau_0
        self.mu_0 = mu_0
        self.scalar_theta = scalar_theta
        self.scalar_eta = scalar_eta
        self.scalar_rho = scalar_rho
        self.scalar_sigma1 = scalar_sigma1
        self.scalar_sigma2 = scalar_sigma2
        self.scalar_sigma3 = scalar_sigma3

        # initial value for endm layer
        self.Endm_kernel_initializer = initializers.constant(self.Endm_initialization.T)

        # initialize with prior information: (1) endm: A; and (2) ADMM params: lambda.
        obs_dim, code_dim = self.E.shape
        assert code_dim == self.output_shape[0]

        # initial value for W and B, which are the learnable params in Update_a_layer
        [UF, SF] = splin.svd(sp.dot(self.E.T, self.E))[:2]
        IF = sp.dot(sp.dot(UF, sp.diag(1. / (SF + 1))), UF.T)
        W = sp.dot(self.E, IF)
        B = IF
        self.W_initializer = initializers.constant(W)
        self.B_initializer = initializers.constant(B)

        # initial value for theta, which is the learnable params in Update_p_layer
        theta = self.mu_0
        if self.scalar_theta:
            self.theta_initializer = initializers.constant(theta)
        else:
            self.theta_initializer = initializers.constant(theta * np.ones(obs_dim, ))

        # initial value for C and eta, which are the learnable params in Update_v1_layer
        C = self.E.T
        self.C_initializer = initializers.constant(C)
        eta = 1 / self.mu_0
        if self.scalar_eta:
            self.eta_initializer = initializers.constant(eta)
        else:
            self.eta_initializer = initializers.constant(eta * np.ones(obs_dim, ))

        # initial value for rho, which is the learnable params in Update_v2_layer
        rho = self.lambda_0 / self.mu_0
        if self.scalar_rho:
            self.rho_initializer = initializers.constant(rho)
        else:
            self.rho_initializer = initializers.constant(rho * np.ones(code_dim, ))

        # initial value for D, which are the learnable params in Update_v3_layer
        [UF1, SF1] = splin.svd(self.tau_0 * self.L)[:2]
        IF1 = sp.dot(sp.dot(UF1, sp.diag(1. / (SF1 + self.mu_0))), UF1.T)
        D = IF1 * self.mu_0
        self.D_initializer = initializers.constant(D)

        # initial value for F and sigma1, which are the learnable params in Update_d1_layer
        F = self.E.T
        self.F_initializer = initializers.constant(F)
        if self.scalar_sigma1:
            self.sigma1_initializer = initializers.constant(np.ones(1, ))
        else:
            self.sigma1_initializer = initializers.constant(np.ones(obs_dim, ))

        # initial value for sigma2, which is the learnable params in Update_d2_layer
        if self.scalar_sigma2:
            self.sigma2_initializer = initializers.constant(np.ones(1, ))
        else:
            self.sigma2_initializer = initializers.constant(np.ones(code_dim, ))

        # initial value for sigma3, which is the learnable params in Update_d3_layer
        if self.scalar_sigma3:
            self.sigma3_initializer = initializers.constant(np.ones(1, ))
        else:
            self.sigma3_initializer = initializers.constant(np.ones(obs_dim, ))

        self.build()

    # start building EMLM-Net
    def build(self):
        input = Input(shape=self.input_patch,  name=self.name + '_Input_layer')
        v1_0  = Input(shape=self.input_shape,  name=self.name + '_v1Input_layer')
        v2_0  = Input(shape=self.output_shape, name=self.name + '_v2Input_layer')
        v3_0  = Input(shape=self.input_shape,  name=self.name + '_v3Input_layer')
        d1_0  = Input(shape=self.input_shape,  name=self.name + '_d1Input_layer')
        d2_0  = Input(shape=self.output_shape, name=self.name + '_d2Input_layer')
        d3_0  = Input(shape=self.input_shape,  name=self.name + '_d3Input_layer')

    # shared at each input patch
        obs_dim = self.input_shape[0]

        v1_k1 = v1_0
        v2_k1 = v2_0
        v3_k1 = v3_0
        d1_k1 = d1_0
        d2_k1 = d2_0
        d3_k1 = d3_0

        v1_k2 = v1_0
        v2_k2 = v2_0
        v3_k2 = v3_0
        d1_k2 = d1_0
        d2_k2 = d2_0
        d3_k2 = d3_0

        ind_1 = input[:, 0 * obs_dim: 1 * obs_dim]
        ind_2 = input[:, 1 * obs_dim: 2 * obs_dim]

        for k in range(self.number_layers):
            shared_Update_a_layer = Update_a_layer(self.output_shape[0],
                                                   self.W_initializer,
                                                   self.B_initializer,
                                                   name=self.name + 'Update_a_layer_{}'.format(k+1))

            shared_Update_p_layer = Update_p_layer(self.input_shape[0],
                                                   self.scalar_theta,
                                                   self.theta_initializer,
                                                   name=self.name + 'Update_p_layer_{}'.format(k+1))

            shared_Update_v1_layer = Update_v1_layer(self.input_shape[0],
                                                     self.C_initializer,
                                                     self.scalar_eta,
                                                     self.eta_initializer,
                                                     name=self.name + 'Update_v1_layer_{}'.format(k+1))

            shared_Update_v2_layer = Update_v2_layer(self.output_shape[0],
                                                     self.scalar_rho,
                                                     self.rho_initializer,
                                                     name=self.name + 'Update_v2_layer_{}'.format(k+1))

            shared_Update_v3_layer = Update_v3_layer(self.input_shape[0],
                                                     self.D_initializer,
                                                     name=self.name + 'Update_v3_layer_{}'.format(k+1))

            shared_Update_d1_layer = Update_d1_layer(self.input_shape[0],
                                                     self.F_initializer,
                                                     self.scalar_sigma1,
                                                     self.sigma1_initializer,
                                                     name=self.name + 'Update_d1_layer_{}'.format(k+1))

            shared_Update_d2_layer = Update_d2_layer(self.output_shape[0],
                                                     self.scalar_sigma2,
                                                     self.sigma2_initializer,
                                                     name=self.name + 'Update_d2_layer_{}'.format(k+1))

            shared_Update_d3_layer = Update_d3_layer(self.input_shape[0],
                                                     self.scalar_sigma3,
                                                     self.sigma3_initializer,
                                                     name=self.name + 'Update_d3_layer_{}'.format(k+1))

            # the 1-st pixel in one patch
            a_k1 = shared_Update_a_layer([v1_k1, d1_k1, v2_k1, d2_k1])
            p_k1 = shared_Update_p_layer([ind_1, v1_k1, v3_k1, d3_k1])
            v1_k1 = shared_Update_v1_layer([ind_1, a_k1, p_k1, d1_k1])
            v2_k1 = shared_Update_v2_layer([a_k1, d2_k1])
            v3_k1 = shared_Update_v3_layer([p_k1, d3_k1])
            d1_k1 = shared_Update_d1_layer([d1_k1, a_k1, v1_k1])
            d2_k1 = shared_Update_d2_layer([d2_k1, a_k1, v2_k1])
            d3_k1 = shared_Update_d3_layer([d3_k1, p_k1, v3_k1])

            # the 2-nd pixel in one patch
            a_k2 = shared_Update_a_layer([v1_k2, d1_k2, v2_k2, d2_k2])
            p_k2 = shared_Update_p_layer([ind_2, v1_k2, v3_k2, d3_k2])
            v1_k2 = shared_Update_v1_layer([ind_2, a_k2, p_k2, d1_k2])
            v2_k2 = shared_Update_v2_layer([a_k2, d2_k2])
            v3_k2 = shared_Update_v3_layer([p_k2, d3_k2])
            d1_k2 = shared_Update_d1_layer([d1_k2, a_k2, v1_k2])
            d2_k2 = shared_Update_d2_layer([d2_k2, a_k2, v2_k2])
            d3_k2 = shared_Update_d3_layer([d3_k2, p_k2, v3_k2])

        v2_k1 = Norm_layer(name=self.name + 'Output_Norm_Layer1')(v2_k1)
        v2_k2 = Norm_layer(name=self.name + 'Output_Norm_Layer2')(v2_k2)

    # Regularizers
        v2_dif = v2_k1 - v2_k2
        v3_dif = v3_k1 - v3_k2

        reg1 = regularizers.l1(self.beta)(v2_dif)
        reg2 = regularizers.l1(self.gamma)(v3_dif)

        net = Dense(units=self.input_shape[0],
                    use_bias=False,
                    kernel_initializer=self.Endm_kernel_initializer,
                    kernel_constraint=MinMaxVal(min_value=1e-6, max_value=0.99),
                    name=self.name + 'Endm_layer')

        y_k1 = net(v2_k1)
        y_k2 = net(v2_k2)

        output1 = Recon_layer(self.input_shape[0],
                              name=self.name + 'Output_Recon_layer1')([y_k1, v3_k1])

        output2 = Recon_layer(self.input_shape[0],
                              name=self.name + 'Output_Recon_layer2')([y_k2, v3_k2])

        output = K.concatenate([output1, output2], axis=-1)

        self.model = Model(inputs=[input, v1_0, v2_0, v3_0, d1_0, d2_0, d3_0],
                           outputs=[output], name=self.name)

        self.model.add_loss(reg1)
        self.model.add_loss(reg2)

##############################################################################################################
# Define callbacks to visualize the decoder weights/endm_sig and the abundance map.
##############################################################################################################
class Collect_intermediate_value(Callback):
    def __init__(self, log_dir, val_x, valid_epoch, **kwargs):
        self.log_dir = log_dir
        self.val_x = val_x
        self.valid_epoch = valid_epoch
        self.est_endm_sig = {}
        self.est_abundance = {}

        super(Collect_intermediate_value, self).__init__(*kwargs)

    def collect_est_endm_sig(self, title):
        est_endm_sig = self.decoder_layer.get_weights()[0].T
        self.est_endm_sig[title] = est_endm_sig

    def collect_est_abundance(self, title):
        est_abundance = self.Encoder.predict(self.val_x, batch_size=64)
        self.est_abundance[title] = est_abundance

    def on_train_begin(self, logs=None):
        # get decoder layer where the weights are the est endmember signature
        self.decoder_layer = self.model.layers[-15]

        # get the encoder model that output the latent distribution parameter
        for layer in self.model.layers:
            if 'Output_Norm_Layer1' in layer.name:
                encoder_output_layer = layer
                break
        self.Encoder = Model(self.model.input, encoder_output_layer.output)

        # collect estimated value
        self.collect_est_endm_sig(title='epoch0')
        self.collect_est_abundance(title='epoch0')

        super(Collect_intermediate_value, self).on_train_begin(logs)

    def on_train_end(self, logs=None):
        self.collect_est_endm_sig(title='finalepoch')
        self.collect_est_abundance(title='finalepoch')
        write_data(data=self.est_endm_sig, file_path=self.log_dir + 'intermediate_est_Endm_sig.pkl')
        write_data(data=self.est_abundance, file_path=self.log_dir + 'intermediate_est_abundance.pkl')

        super(Collect_intermediate_value, self).on_train_end(logs)

    def on_epoch_end(self, epoch, logs=None):
        # collect estimated value
        if epoch % self.valid_epoch == 0:
            self.collect_est_endm_sig(title='epoch{}'.format(epoch))
            self.collect_est_abundance(title='epoch{}'.format(epoch))
            write_data(data=self.est_endm_sig, file_path=self.log_dir + 'intermediate_est_Endm_sig.pkl')
            write_data(data=elf.est_abundance, file_path=self.log_dir + 'intermediate_est_abundance.pkl')

        super(Collect_intermediate_value, self).on_epoch_end(epoch, logs)

##############################################################################################################
# define callbacks to print and summary performance report into Readme.txt file
##############################################################################################################

class Print_intermediate_value(Callback):
    def __init__(self, readme_path, true_endm_sig, true_abundance, val_x, valid_epoch, **kwargs):
        self.readme_path = readme_path
        self.val_x = val_x
        self.true_abundance = true_abundance
        self.true_endm_sig = true_endm_sig
        self.valid_epoch = valid_epoch

        super(Print_intermediate_value, self).__init__(**kwargs)

    def collect_est_endm_sig(self):
        est_endm_sig = self.decoder_layer.get_weights()[0].T
        return est_endm_sig

    def collect_est_abundance(self):
        est_abundance = self.Encoder.predict(self.val_x, batch_size=64)
        return est_abundance

    def summary(self, epoch):
        # collect estimated endm
        est_endm_sig = self.collect_est_endm_sig()
        # calc metrics
        sad = angle_distance_metric(self.true_endm_sig.T, est_endm_sig.T)
        # print and summary SAD
        summary_str = 'Epoch ' + str(epoch) + ' est Endms\r\n' + ' SAD: %f\r\n' % sad
        print(summary_str)
        summary2readme(summary_str, readme_path=self.readme_path + 'Readme.txt')

        # collect estimated abundance
        est_abundance = self.collect_est_abundance()
        # calc metrics
        rmse = RMSE_metric(self.true_abundance, est_abundance)
        aad = angle_distance_metric(self.true_abundance, est_abundance)
        aid = abundance_information_divergence_metric(self.true_abundance, est_abundance)

        # print and summary RMSE
        summary_str = 'Epoch ' + str(epoch) + ' est Abundance\r\n' + ' RMSE: %f\r\n' % rmse \
                      + 'AAD: %f\r\n' % aad \
                      + 'AID: %f\r\n' % aid
        print(summary_str)

        summary2readme(summary_str, readme_path=self.readme_path + 'Readme.txt')

    def on_train_begin(self, logs=None):
        # get decoder layer where the weights are the est endmember signature
        self.decoder_layer = self.model.layers[-15]

        # get the encoder model that output the abundance
        self.Encoder = Model(self.model.input, self.model.layers[-16].output)

        super(Print_intermediate_value, self).on_train_begin(logs)

    def on_train_end(self, logs=None):
        super(Print_intermediate_value, self).on_train_end(logs)

    def on_epoch_end(self, epoch, logs=None):
        # collect estimated value
        if epoch % self.valid_epoch == 0:
           self.summary(epoch)

        super(Print_intermediate_value, self).on_epoch_end(epoch, logs)
