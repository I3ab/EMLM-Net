"""
Description: train and evaluate the EMLM_Net
"""

# Futures
from __future__ import print_function

import sys
import os

import keras.layers
import numpy as np
from keras import Model

# getting the directory where this file is located
current_dir = os.path.dirname(os.path.realpath(__file__))
# getting the parent directory and adding it to the path
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from timeit import default_timer as timer
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras import optimizers
from Modules.utils import *
from Modules.EMLM_Net import *
from Modules.Losses import *
import tensorflow as tf

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

# gpu setting
gpus = tf.config.experimental.list_physical_devices('GPU')

if gpus:
    # Restrict TensorFlow to only use the first GPU
    try:
        tf.config.experimental.set_visible_devices(gpus[0], 'GPU')
        tf.config.experimental.set_memory_growth(gpus[0], True)
        logical_gpus = tf.config.experimental.list_logical_devices('GPU')
        print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPU")
    except RuntimeError as e:
        # Visible devices must be set before GPUs have been initialized
        print(e)

# {code}
def main(hparams):
    parent_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

    # ------------------------------------------  1. load data ------------------------------------------
    data_params = {'HSI data path': os.path.join(parent_dir, 'Data/data_jasper.pkl'),
                   'True abundance path': os.path.join(parent_dir, 'Data/abundance_jasper.pkl'),
                   'True Endmember signature path': os.path.join(parent_dir, 'Data/endmember_jasper.pkl'),
                   'data_sup path': os.path.join(parent_dir, 'Data/data_jasper_sup.pkl'),
                   'img_size': (100, 100)}

    hsi_data = read_data(data_params['HSI data path'])
    true_abundances = read_data(data_params['True abundance path'])
    true_endm_sig = read_data(data_params['True Endmember signature path'])
    data_sup = read_data(data_params['data_sup path'])

    NO_DATA, NO_Bands = hsi_data.shape
    _, NO_Endms = true_abundances.shape

    data_params['NO_Bands'] = NO_Bands
    data_params['NO_Endms'] = NO_Endms
    data_params['NO_DATA'] = NO_DATA

    assert NO_DATA == np.prod(data_params['img_size'])

    # clip abundance to avoid overflow of loss and metric calculation
    true_abundances = np.clip(true_abundances, 1e-6, 0.99)

    train_x = data_sup
    train_y = data_sup
    train_pseudo_v1_0 = np.zeros_like(hsi_data)
    train_pseudo_v2_0 = np.zeros_like(true_abundances)
    train_pseudo_v3_0 = np.zeros_like(hsi_data)
    train_pseudo_d1_0 = np.zeros_like(hsi_data)
    train_pseudo_d2_0 = np.zeros_like(true_abundances)
    train_pseudo_d3_0 = np.zeros_like(hsi_data)

    array_a = np.diag([0.99] * (NO_Bands - 1), -1)
    array_b = np.diag([1] * NO_Bands)
    array_c = np.diag([0.99] * (NO_Bands - 1), 1)
    W1 = array_a + array_b + array_c

    W = np.minimum(W1, 1)
    L = np.diag(np.sum(W, axis=1))-W

    train_x = [train_x, train_pseudo_v1_0, train_pseudo_v2_0, train_pseudo_v3_0,
               train_pseudo_d1_0, train_pseudo_d2_0, train_pseudo_d3_0]
    # ------------------------------------------ 2. build model ------------------------------------------
    model_params = {'input_shape': (NO_Bands,),
                    'input_patch': (2*NO_Bands,),
                    'output_shape': (NO_Endms,),
                    'number_layers': hparams['number_layers'],
                    'beta': hparams['beta'],
                    'gamma': hparams['gamma'],
                    'name': 'EMLM',
                    'Endm_initialization': hparams['Endm_init'],  # decoder initialization
                    'E': hparams['Endm_init'],                    # encoder initialization
                    'L': L,
                    'lambda_0': 0.001, 'tau_0': 0.001, 'mu_0': 0.001}

    # UADMMBUNet customize objects
    EMLM_Net_customize_object = {'Update_a_layer': Update_a_layer,
                                 'Update_p_layer': Update_p_layer,
                                 'Update_v1_layer': Update_v1_layer,
                                 'Update_v2_layer': Update_v2_layer,
                                 'Update_v3_layer': Update_v3_layer,
                                 'Update_d1_layer': Update_d1_layer,
                                 'Update_d2_layer': Update_d2_layer,
                                 'Update_d3_layer': Update_d3_layer,
                                 'Norm_layer': Norm_layer,
                                 'Recon_layer': Recon_layer,
                                 'MinMaxVal': MinMaxVal}

    initial_learning_rate = 1e-5
    decay_steps = 50
    decay_rate = 0.95
    learning_rate_fn = tf.keras.optimizers.schedules.ExponentialDecay(
        initial_learning_rate, decay_steps, decay_rate)

    model = EMLM(**model_params).model
    optimizer = optimizers.Adam(learning_rate=learning_rate_fn)

    def Composite_Loss(y_true, y_pred):
        A = -tf.keras.losses.cosine_similarity(y_true, y_pred)
        sad = tf.math.acos(A)
        return sad

    model.compile(optimizer=optimizer, loss=Composite_Loss)

    # ---------------------------- 3. experiment log ----------------------------
    Readme = f"evaluate model: {model_params['name']} on synthetic dataset.\r\n" \
             f"Hyperparameters: {hparams}.\r\n"

    kwargs = {'Readme': Readme}

    if not os.path.exists(os.path.join(parent_dir, 'Result/')):
        os.mkdir(os.path.join(parent_dir, 'Result/'))
    program_log_path, model_checkpoint_dir, tensorboard_log_dir, model_log_dir = create_project_log_path(
        project_path=os.path.join(parent_dir, 'Result/'), **kwargs)

    # Save JSON config to disk
    save_model2json(model, model_checkpoint_dir + model_params['name'] + '_model_config.json')
    model.save_weights(model_checkpoint_dir + model_params['name'])

    # summary model to Readme
    summary_model2_readme(model, readme_path=program_log_path + 'Readme.txt')

    # ---------------------------- 4. train ----------------------------
    callbacks = [ModelCheckpoint(filepath=model_checkpoint_dir + model_params['name'],  # + '_weights.h5',
                                 save_best_only=True,
                                 save_weights_only=True,
                                 monitor='loss')]
    start = timer()
    model.fit(x=train_x, y=train_y,
              callbacks=callbacks,
              batch_size=hparams['batch_size'],
              epochs=hparams['epochs'],
              verbose=hparams['verbose'])
    train_time = timer() - start
    # free memory
    del model
    # ---------------------------- 5. evaluate ----------------------------
    # load model
    new_model = restore_model_from_json(model_checkpoint_dir + model_params['name'] + '_model_config.json',
                                        customize_obejct=EMLM_Net_customize_object)

    new_model = load_model_weights(new_model, model_checkpoint_dir + model_params['name'])

    # extract endms
    est_endm_sig = new_model.layers[-17].get_weights()[0].T

    # est abundance
    abu = new_model.layers[-18].output
    abu_net = Model(new_model.inputs, abu)

    # evaluation
    start = timer()
    est_abundance = abu_net.predict(x=train_x, batch_size=hparams['batch_size'])

    eval_time = timer() - start

    # free memory
    del new_model, abu_net

    write_data(est_endm_sig,  file_path=tensorboard_log_dir + 'est_endm_sig.pkl')
    write_data(est_abundance, file_path=tensorboard_log_dir + 'est_abundance.pkl')

    # ---------------------------- post_processing ----------------------------

    # calc metrics for EMLM_Net endm_sig
    sad = angle_distance_metric(true_endm_sig.T, est_endm_sig.T)

    # print and summary
    summary_str = model_params['name'] + f" est Endms SAD: {sad}.\r\n"
    print(summary_str)
    summary2readme(summary_str, readme_path=program_log_path + 'Readme.txt')

    # calc abundance metrics
    rmse = RMSE_metric(true_abundances, est_abundance)
    aad = angle_distance_metric(true_abundances, est_abundance)
    aid = abundance_information_divergence_metric(true_abundances, est_abundance)

    # print and summary RMSE
    summary_str = model_params['name'] + ' est Abundance:\r\n' \
                  + 'RMSE: %f\r\n' % rmse \
                  + 'AAD: %f\r\n' % aad \
                  + 'AID: %f\r\n' % aid \
                  + 'Eval time: %f s\r\n' % eval_time \
                  + 'Train time: %f s\r\n' % train_time
    print(summary_str)
    summary2readme(summary_str, readme_path=program_log_path + 'Readme.txt')

if __name__ == '__main__':
    # ----------------------------------------------------------------hyper-parameters----------------------------------------------------------------
    parent_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    data_params = {'Endm_initialization path': os.path.join(parent_dir, 'Data/Endm_init_jasper.pkl')}
    Endm_initialization = read_data(data_params['Endm_initialization path'])  # 5 runs

    for i in range(1):
        print(i)
        hparams = {'verbose': 1,
                   'beta': 1e-5,
                   'gamma': 1e-3,
                   'Endm_init': Endm_initialization[:, i*4: (i+1)*4],
                   'number_layers': 13,
                   'epochs': 50,
                   'batch_size': 64}
        main(hparams)